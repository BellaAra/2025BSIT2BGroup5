<html>
<head> <title>ABOUT US</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="assets/css/navbarStyle.css">
  <link rel="stylesheet" href="assets/css/footerStyle.css">

</head>

<style>

body, html {
 margin: 0;
 padding: 0;
}

.navbar{
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 10px 40px;
	background-color: #FFFFFF;
	position: sticky;
	z-index: 10;
	top: 0;
	font-family: "Montserrat", variable;
	box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
}

.navleft{
	display: flex;
	align-items: center;
	gap: 100px;
}

.navleft ul{
	display: flex;
	list-style: none;
	gap: 150px;
	margin: 0;
	padding:0;
	
}

.navbar li{
	color: #013450;
	font-weight: bold;
	cursor: pointer;
	transition: color 0.3s ease;
}

.navbar li:hover{
	color: #006CA5;
}

#circleicon{
	width: 50px;
	height: 50px;
	border-radius: 50%;
	background-color: #006CA5;
}

#rectanglead{
	width: 150px;
	height: 50px;
	background-color: #E7E7E7;
}

.navbar a{
	text-decoration: none;
	color: #013450;
}



.website-headerImage{
	background-image: url('images/aboutus.png');
	background-size:cover;
	background-position: center;
	background-repeat: no-repeat;
	flex-shrink: 0;
	
	z-index: 9;
	height: 400px;
	filter: brightness(80%);	
}




.first_about-us{
	display: flex;
	align-items: flex-start;
	padding: 50px;
	max-width: 1300px;
	margin: 0px 0px 0px 30px; /*center content*/
	
	position: relative;
}

.about-image-container{
	position: relative;
	margin-right: 100px; /*gap between text and img*/
	top: -150px;
	width: 600px;
	height: 700px;
	
	flex-shrink:0;
	box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.5);
}

.about-image-container img{
	display: block;
	object-fit:cover;
	object-position: 40% 80%;
	width: 100%;
	height: 100%;
}


.first-paragraph{
	width: 60%;
}


.first-paragraph h1{
	color: #006ca5;
	margin-top: 0;
	font-family: "Montserrat", variable;
	font-weight: 700;
	font-size: 60px;
}

.first-paragraph p{
	color: black;
	margin-top: -20px;
	margin-bottom: 50px;
	font-family: "Montserrat", variable;
	font-weight: 400;
	font-size: 18px;
	
	text-align: justify;
}




@media (max-width: 768px) {
    .website-headerImage {
        height: 200px;
		width: auto;
    }

    .first_about-us {
        flex-direction: column; /* Stacks the items vertically */
        align-items: center; /* Centers items horizontally */
        padding: 20px 0; /* Adjusts top/bottom padding */
        max-width: 100%;
        margin: auto; /* Centers the whole section */
    }

    .about-image-container {
        position: static; /* This removes the desktop positioning */
        margin: 0 auto 20px auto; /* Centers the image and adds bottom margin */
        top: 0;
        width: 90%; /* Responsive width for the image */
        height: auto;
    }

    .about-image-container img {
        width: 100%;
        height: auto; /* Allows the image to scale proportionally */
        object-position: 50% 50%;
    }

    .first-paragraph {
        width: 100%; /* Responsive width for the text */
        padding: 0 10px;
        box-sizing: border-box;
    }

    .first-paragraph h1 {
        margin-top: 0;
        margin-bottom: 10px;
        font-size: 24px;
        text-align: center;
    }

    .first-paragraph p {
        margin-top: 0;
        margin-bottom: 15px;
        font-size: 14px;
        line-height: 1.5;
        text-align: justify;
    }
	
	 .navbar {
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      padding: 10px 15px;
      gap: 10px;
      position: sticky;
      top: 0;
      background-color: #fff;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 10;
  }

  .navleft {
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 15px;  /* smaller gap between icon and nav links */
      flex: 1;
  }

  #circleicon {
      width: 30px;
      height: 30px;
      flex-shrink: 0;
      background-color: #006CA5;
      border-radius: 50%;
  }

  .navleft ul {
      display: flex;
      flex-direction: row;  /* horizontal links */
      gap: 10px;           /* smaller gap between links */
      margin: 0;
      padding-left: 0;
      flex: 1;
      list-style: none;
      text-align: left;
      padding-right: 20px;  /* add space between links and rectangle */
      overflow-x: auto;     /* allow horizontal scroll if needed */
  }

  .navleft ul li {
      font-size: 0.55rem;   /* smaller font */
      font-weight: 600;
      white-space: nowrap; /* prevent wrapping */
  }

  .navleft ul li a {
      color: #013450;
      text-decoration: none;
      display: block;
      padding-right: 5px;  /* some padding inside links */
  }

  .navleft ul li a:hover {
      color: #006CA5;
  }

  #rectanglead {
      width: 90px;           /* reduce width more */
      height: 30px;
      background-color: #E7E7E7;
      flex-shrink: 0;
      margin-left: auto;     /* push to right */
      border-radius: 4px;
  }
  
}


</style>

<body>

<?php include 'views/navbar.php' ?>

<header class = "website-headerImage">
</header>

<section class = "first_about-us">
	<div class = "about-image-container">
	<img src = "images/kennethaboutus.jpg"></img>
	</div>
	
	<div class = "first-paragraph">
	<h1>ABOUT S-A-S</h1>
	<p>Three BSIT graduates from the University of St. La Salle, <b>Kaori, Nessy,</b> and <b>Loraine,</b> united their
	skills to create an innovative project called Save-A-Spark. The trio, who were part of a friend group known as LingGang,
	initially developed the system as a group project for their Web Design class taught by Ms. Dairin Jaganap. Recognizing its
	potential, they decided to evolve the project into a full-fledged Electricity Household Management System. The system's purpose
	is to help households efficiently manage their electricity consumption. </p>
	<p></p>
	<p>To bring their vision to life, they sought the assistance 
	of their friend, Kenneth, who provided crucial programming support. The combined efforts of Kaori, Nessy, and Loraine, along with
	Kenneth's help, transformed a simple class assignment into a functional and practical solution for energy management. Save-A-Spark 
	became a testament to their dedication and collaborative spirit. This system not only fulfilled their academic requirements but also showcased 
	their passion for using technology to solve real-world problems. Their journey from a university project to a potential business venture highlights
	the power of teamwork and innovation. (This is just a placeholder for Gemini for now...linggang guli guli wacha)</p>

	</div>

</section>

<hr>

<section class = "second_about-us">
<div class = "background-image-about-us">
</div>

<div class = "text-container">
	<div class = "text_section2">
	</div>
</div>

</section>

<?php include 'views/footer.php' ?>
</body>

</html>

<html>
<head><title> About Us </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link rel = "stylesheet" href="assets/css/aboutusStyle.css" >
</head>


<body>

<?php require 'views/navbar.php' ?>
 
<header class = "website-headerImage">
</header>

<section class = "first_about-us">
	<div class = "about-image-container">
	<img src = "images/kennethaboutus.jpg"></img>
	</div>
	
	<div class = "first-paragraph">
	<h1>ABOUT S-A-S</h1>
	<p>Three BSIT graduates from the University of St. La Salle, <b>Kaori, Nessy,</b> and <b>Loraine,</b> united their
	skills to create an innovative project called Save-A-Spark. The trio, who were part of a friend group known as LingGang,
	initially developed the system as a group project for their Web Design class taught by Ms. Dairin Jaganap. Recognizing its
	potential, they decided to evolve the project into a full-fledged Electricity Household Management System. The system's purpose
	is to help households efficiently manage their electricity consumption. </p>
	<p></p><br>
	<p>To bring their vision to life, they sought the assistance 
	of their friend, Kenneth, who provided crucial programming support. The combined efforts of Kaori, Nessy, and Loraine, along with
	Kenneth's help, transformed a simple class assignment into a functional and practical solution for energy management. Save-A-Spark 
	became a testament to their dedication and collaborative spirit. This system not only fulfilled their academic requirements but also showcased 
	their passion for using technology to solve real-world problems. Their journey from a university project to a potential business venture highlights
	the power of teamwork and innovation. (This is just a placeholder for Gemini for now...linggang guli guli wacha)</p>

<!--placeholder lng ni from gemini-->
	</div>

</section>

<hr>

<section class = "second_about-us">
<div class = "secondABContainer">
<img src = "images/electrician.png"></img>
</div>
<div class = "textboxContainer">
	<h1>THE <span class = "sas">S-A-S</span> PROMISE</h1>
	<p>At SAS, our mission is to make electricity <b>simple</b>, <b>clear</b>, and <b>easy to manage</b>. We believe that everyone deserves 
		the power to understand where their energy goes and how to use it wisely. That’s why we built an electricity monitoring
		 system that’s designed for people, not just engineers — intuitive, reliable, and built to fit into daily life.
		  With SAS, families can lower their bills, businesses can save on costs, and communities can work together toward
		   greener habits.</p><br>
	<p>We dream of a world where energy is no longer confusing, wasteful, or overwhelming. Instead, electricity becomes
		 something people feel confident managing — like <b>a partner in everyday living</b>. At SAS, we envision neighborhoods 
		 powered by awareness, businesses thriving on efficiency, and households enjoying the freedom of lower costs and 
		 smarter choices. Our vision is not only to provide a tool but to inspire a movement: one that turns electricity 
		 monitoring into a habit that supports both financial savings and a sustainable future for the next generation.</p>
</div>

	</section>

<hr>

<section class = "third_about-us">
<div class = "meetTeamContainer">
	<h1>MEET THE TEAM</h1>
</div>
	<div class = "team">
		<img src = "images/team.jpg">
	</div>
	<p><i>Kaori Hirose (left), Nessy Bermudez (center), and Loraine Acosta(right) pose for a group picture.</i></p>
	<p class = "meetTeamDesc">
	At Save-A-Spark, our strength lies in the people behind the mission. What began as a small project,
	 sparked by curiosity and the desire to make electricity usage clearer, has evolved into a
	  growing initiative for smarter and more sustainable energy practices. At the foundation of
	   Save-A-Spark are Kaori Hirose, Loraine Acosta, and Nessy Bermudez, three passionate innovators
	    who brought together creativity, strategy, and technical expertise to turn an idea into reality.
		 Kaori's innovative mindset and eye for design ensured our solutions are both practical and
		  user-friendly. Loraine's strong sense of organization and strategy provided the direction
		   to keep our vision on track, while Nessy's technical knowledge and problem-solving skills
		    powered the development of our electricity monitoring system.
<br><br>
Together, they transformed Save-A-Spark from a simple concept into a platform that empowers
 households, businesses, and communities to take control of their energy use. What started as a 
 little project has become a spark of change — one that continues to grow as new talents, partners,
  and supporters join the journey. Today, Save-A-Spark is not just a team, but a movement dedicated
   to building a future where energy is understood, managed responsibly, and used to create a brighter 
   tomorrow for all.
<br><br>
   <span class = "lastLine">We invite you to be part of this mission whether as a <span id = "blueLine">supporter</span>, <span id = "blueLine">partner</span>, or  <span id = "blueLine">future team
    member </span>— and help us keep the spark alive.</span>
		</p>

	</section>

<?php require 'views/footer.php' ?>

</body>
</html>
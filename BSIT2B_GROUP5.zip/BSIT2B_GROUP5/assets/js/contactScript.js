document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("emailForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();

    const successPopup = document.getElementById("popup");
    const errorPopup = document.getElementById("errorPopup");

    if (!name || !email || !message) {
      errorPopup.classList.add("show");

      setTimeout(() => {
        errorPopup.classList.remove("show");
      }, 3000);
      return;
    }

    const subject = encodeURIComponent("Contact from " + name);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);

    window.location.href = `mailto:arabellaloraine02@gmail.com?subject=${subject}&body=${body}`;

    successPopup.classList.add("show");

    setTimeout(() => {
      successPopup.classList.remove("show");
    }, 3000);
  });
});

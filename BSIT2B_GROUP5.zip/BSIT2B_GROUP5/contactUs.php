<!DOCTYPE html>
<html>
<head>
  <title>CONTACT US</title>

  <!-- IMPORTED FONT-->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="contactusstyle.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--CONTACT US CSS STYLESHEET-->
  <link rel="stylesheet" href="assets/css/contactusStyle.css">
</head>
<body>

  <h1>CONTACT US</h1>

<!-- CONTAINER FOR INPUT FIELDS AND TEXTAREA -->
  <div class="maincontainer">

    <form id="emailForm" class="forms">

      <div class="input">
        <p>NAME</p>
        <input type="text" id="name" placeholder="e.g. Kenneth Ciriaco">
      </div>

      <div class="input">
        <p>EMAIL</p>
        <input type="text" id="email" placeholder="s2400726@usls.edu.ph">
      </div>

      <div class="input">
        <p>MESSAGE</p>
        <textarea id="message" class="messagebox" placeholder="Hello, I have a report to make..."></textarea>
      </div>

      <div class="send-button">
        <button type="submit">Send</button>
      </div>

    </form>

    <!-- IMAGE BESIDE INPUT FIELDS AND TEXTAREA -->
    <div class="imagesection">
      <img src="images/contactIMG.jpg" alt="Contact Image">
    </div>

  </div>

  <!-- DIV FOR POP-UP MESSAGES -->
  <div id="popup" class="popup">
  <div class="popup-content">
    <p> Message Sent!</p>
  </div>
</div>

<div id="errorPopup" class="popup">
  <div class="popup-content">
    <p>Please fill out all fields.</p>
  </div>
</div>

<!-- JAVASCRIPT FOR POP-UP MESSAGES -->
<script src="assets/js/contactScript.js"></script>

</body>
</html>

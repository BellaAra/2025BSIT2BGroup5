<html>
<head><title> CONTACT US </title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="contactusstyle.css">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
	<h1> CONTACT US </h1>
	<div class="maincontainer">
	
		<div class="forms">
		
			<div class="input">
			<p> NAME </p>
				<input type="text" placeholder="e.g. Kenneth Ciriaco">
			</div>

			<div class="input"> 
			<p> EMAIL </p>
				<input type="text" placeholder="s2400726@usls.edu.ph">
			</div>

			<div class="input"> 
			<p> MESSAGE </p>
				<textarea class="messagebox" placeholder="Hello, I have a report to make..."></textarea>
			</div>
			
	</div>

	<div class="imagesection">
	<img src="images/contactIMG.jpg">
	</div>
	</div>
</body>
</html>
<!DOCTYPE html>
<html>
<head><title> Dashboard </title>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Save a Spark</title>

  <!-- IMPORTED FONTS -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"/>

  <!-- DASHBOARD CSS STYLESHEET -->
  <link rel="stylesheet" href="assets/css/dashboardStyle.css">

</head>
<body>
<?php require 'views/navbar.php';?>

  <!-- HEADER & SEARCH -->
  <header class="webHeader">
    <h1 id="headerText">Save a <span class="sparkColor">spark</span> today!</h1>
    <p>Let's get you started!</p>

    <div class="searchBar">
      <input type="text" placeholder="Search..." class="searchInput">
      <button class="searchBtn">Search</button>
    </div>
  </header>

  <!-- MAIN BUTTONS -->
  <section class="main-buttons">
<a href="edithousehold.php" class="action-btn">
  <img src="images/house.png" alt="House Icon" />
  <span>MANAGE<br>HOUSEHOLD</span>
</a>

<a href="tracking.php" class="action-btn">
  <img src="images/plug.png" alt="Plug Icon" /><br>
  <span>TRACK<br>CONSUMPTION</span>
</a>

  </section>

  <!-- STATISTICS SECTION -->
  <section class="statSection">

    <h2 class="statisticsTitle">Statistics and Ranking</h2>

    <div class="statsBox">
      <!-- LINE GRAPH SECTION-->
      <div class="lineGraphSection">
        <div class="lineGraph">
          <img src="images/linegraph.png" alt="Line Graph" />
        </div>
        <p class="graphLabel">Months with Highest Consumption</p>
      </div>

      <!-- PIE CHART SECTION -->
      <div class="pieChartSection">
        <div class="pieChart">
          <img src="images/piechart.png" alt="Pie Chart"/>
        </div>
        <p class="graphLabel">Most Used Appliances</p>
      </div>

    </div>
  </section>

  <!-- POWER CONSERVATION TIPS -->
  <section class="tipSection">
    <h2 class="statisticsTitle">Power Conservation Tips</h2>

    <!-- TIP #1-->
    <div class="tip">

      <div class="tipBox">Spark #1</div>
      <div class="tipContent">
        <p class="tipText">
          Even if your device isn't connected, a charger plugged into the wall can still draw a small amount of "phantom load" or "vampire power." Unplugging it completely eliminates this waste.
        </p>
        <img src="images/lightbulb.png" alt="Plug Icon" class="tipIcon"/>
      </div>

    </div>

    <!-- TIP #2 -->
    <div class="tip">

      <div class="tipBox">Spark #2</div>
      <div class="tipContent">
        <p class="tipText">
          Many devices have power-saving modes or settings that can extend battery life. Utilize these by dimming screens, turning off unnecessary background apps, and disabling features like Wi-Fi or Bluetooth.
        </p>
        <img src="images/battery.png" alt="Battery Icon" class="tipIcon"/>
      </div>

    </div>

    <!-- TIP #3 -->
    <div class="tip">

      <div class="tipBox">Spark #3</div>
      <div class="tipContent">
        <p class="tipText">
          Maximize the use of natural light during the day by opening curtains and blinds. Instead of immediately reaching for the air conditioner, open windows and doors.
        </p>
        <img src="images/lightning.png" alt="Energy Icon" class="tipIcon"/>
      </div>
      
    </div>
  </section>

<?php require 'views/footer.php';?>
</body>
</html>

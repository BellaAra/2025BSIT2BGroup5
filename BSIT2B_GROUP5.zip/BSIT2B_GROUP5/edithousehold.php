<html>
<head>
<title> Edit Household </title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- EDIT HOUSEHOLD CSS STYLESHEET -->
<link rel="stylesheet" href="assets\css\edithouseholdStyle.css">

<!-- IMPORTED FONT -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>

<body>
<?php require 'views/navbar.php' ?>

	<div class="household-container">

  <!-- HOUSEHOLD GROUP IMAGE -->
  <div class="left-panel">
    <div class="household-photos">
      <img src="images\lor.jpg" alt="Member" class="circle">
      <img src="images\kao.jpg" alt="Member" class="centercircle">
      <img src="images\nessy.jpg" alt="Member" class="circle">
    </div>

    <h2>ERM</h2>

  <!-- MANAGE HOUSEHOLD BUTTON -->
    <a href="#" class="manage-btn">Manage</a>
  </div>

	<div class="vertical-line"></div>

  <div class="right-panel">
    <h2>EDIT HOUSEHOLD</h2>
    <h3>HOUSEHOLD MEMBERS</h3>

  <!-- FIRST MEMBER SECTION -->
    <div class="member">
      <img src="images\regi.jpg" alt="member" class="circle-sm">
      <span>Regiemer B. Garde</span>
      <select>
        <option>Mother</option>
        <option>Father</option>
        <option>Son</option>
        <option>Daughter</option>
      </select>
    </div>


  <!-- SECOND MEMBER SECTION -->
    <div class="member">
      <img src="images\kenneth.jpg" alt="member" class="circle-sm">
      <span>Kenneth T. Ciriaco</span>
      <select>
        <option>Father</option>
        <option>Mother</option>
        <option>Son</option>
        <option>Daughter</option>
      </select>
    </div>

  <!-- THIRD MEMBER SECTION -->
    <div class="member">
      <img src="images\lamy.jpg" alt="member" class="circle-sm">
      <span>William Rhoy Laminero</span>
      <select>
        <option>Son</option>
        <option>Mother</option>
        <option>Father</option>
        <option>Daughter</option>
      </select>
    </div>

  </div>
</div>

<?php require 'views/footer.php';?>

</body>
</html>
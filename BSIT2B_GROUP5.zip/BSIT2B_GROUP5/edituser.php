<html>
<head><title> EDIT USER </title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="edituserStyle.css">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>

    <div class="navbar">
        <div class="navleft">
            <div id="circleicon"></div>
            <ul>
                <li><a href="login.php">HOME</a></li>
                <li><a href="Save-A-Spark.php">ABOUT US</a></li>
                <li><a href="whysas.php">WHY SAS</a></li>
                <li><a href="contactus.php">CONTACT</a></li>
            </ul>
        </div>
        <div id="rectanglead"></div>
    </div>

	 </div>
	 
<div class="page-wrapper">
	<div class="maincontainer">
	
		<div class="forms">
		
			<div class="input">
			<p> Address </p>
				<input type="text" placeholder="Lot 6, Blk. 7 Phase 3, Charito Heights  ">
			</div>

<div class="bday-contact">
    <div class="input">
        <p> Birthday </p>
        <input type="text" placeholder="2/10/2006">
    </div>

    <div class="input">
        <p> Contact Number </p>
        <input type="text" placeholder="+63 961 987 4020">
    </div>
</div>

			
			<div class="input"> 
			<p> E-mail </p>
				<textarea class="message-box" placeholder="kaorihirose@gmail.com"></textarea>
			</div>
							<div class="esButton">
				<button class="blueButton"> Edit </button>
				<button class="blueButton"> Save </button>
			</div>
	</div>
	

	<div class="imagesection">
<img src="https://scontent.fceb2-1.fna.fbcdn.net/v/t39.30808-6/486505978_2760691907464138_7040761794507284351_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=a5f93a&_nc_eui2=AeEQDfvmidRPg7PsIc80t-Gg4feJ3qs3RPHh94neqzdE8Z24JORu_47hgibRlRMGK9_g8JBgTqvJ0Rp6aElS6UX0&_nc_ohc=UR4TBAmuuPwQ7kNvwGZTs5H&_nc_oc=Adn1-jgWrtMpPvWNtcFRAAtfj2ZK_YP9kTdDmmCUXN63dbEKybePbh6SpCebIYrJssJW7OxSWasrDfJLPQVNAp58&_nc_zt=23&_nc_ht=scontent.fceb2-1.fna&_nc_gid=ldfuIezJCow1Nt1zKVtkjg&oh=00_AfX1G4RiLgDl1ubi4EzVqNxD0Q9rgJrYaQae2QyPH50DqA&oe=68A15A29">
	<h1> Kaori Hirose </h1>
	<p class="admin"> ADMIN </p>
	
	<p class="profile-email"> kaorihirose@gmail.com </p>
	
<button class="logout-btn" onclick="redirelogin.html"> Logout </button>



		</div>

	</div>
</div>

</body>
</html>

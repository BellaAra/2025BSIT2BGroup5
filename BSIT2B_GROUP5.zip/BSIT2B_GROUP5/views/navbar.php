<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="assets/css/navbarStyle.css">
    <title>Sticky Navbar</title>
</head>

<body>

    <div class="navbar">
        <div class="nav-desktop">
            <div class="navleft">
                <a href="edituser.php"><img id="circleicon" src="images/kao.jpg" alt="Profile Icon" /></a>
                <ul>
                    <li><a href="index.php#home">HOME</a></li>
                    <li><a href="aboutUs.php">ABOUT US</a></li>
                    <li><a href="index.php#whysas-section">WHY SAS</a></li>
                    <li><a href="index.php#contact-section">CONTACT</a></li>
                </ul>
            </div>
            <img id="rectanglead" src="images/logo.png" alt="Rectangle Ad" />
        </div>

        <div class="nav-mobile">
            <div class="hamburger-menu" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>
            <span class="logo-text">SAVE A SPARK</span>
            <div class="mobile-placeholder"></div>
        </div>

        <div class="mobile-sidebar-overlay" onclick="toggleMenu()"></div>

        <div class="mobile-sidebar" id="mobile-sidebar">


        <div class="sidebarTop">
        <div class="mobileLogo">
    <img class="mobileLogoimg" src="images/logo.png"/>
        </div>
         <div class="close-btn" onclick="toggleMenu()">
                    <i class="fas fa-times"></i>
                </div>
</div>

            <div class="sidebar-header">
                <div class="sidebar-user-info">
                    <a href="edituser.php" class="sidebar-user-info" onclick="toggleMenu()">
                    <img id="mobile-profile-icon" src="images/kao.jpg" alt="Profile Icon" />
                    </a>
                                        <span>Kaori</span> 
</div>
            
            </div>

            <ul>
                <li><a href="index.php#home" onclick="toggleMenu()">HOME</a></li>
                <li><a href="aboutUs.php" onclick="toggleMenu()">ABOUT US</a></li>
                <li><a href="index.php#whysas-section" onclick="toggleMenu()">WHY SAS</a></li>
                <li><a href="index.php#contact-section" onclick="toggleMenu()">CONTACT</a></li>
            </ul>
        </div>
    </div>

<script src="assets/js/navbarScript.js"></script>

</body>
</html>
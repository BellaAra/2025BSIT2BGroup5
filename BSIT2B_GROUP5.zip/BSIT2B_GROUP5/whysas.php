<html>
<head> <title> WHY SAS? </title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libertinus+Sans:ital,wght@0,400;0,700;1,400&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<link rel=stylesheet href="whysasstyle.css">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

	<h1> WHY SAVE-A-SPARK? </h1>
	<div class="blueboxcontainer">
	
	<div class="bluebox"> 
		<p> Take control of your electricity <br> with Save-A-Spark</p> </div> <!-- blue box here with the text -->
		
	<div class="sasimage">
		<img src="images/sasIMG.png"></div> <!-- insert image here under the text of the div box, overlapping on top of the div box -->
	</div>

		<p class="description"> Guessing your electric bill is stressful and avoidable. Save-A-Spark turns your daily usage into clear, real-time insights so you always know where your money is going. See estimated costs as you turn things on, set a monthly target, and get gentle alerts before you overshoot. No jargon—just simple numbers, helpful tips, and a dashboard that shows which habits and appliances have the biggest impact.
</p>
		<br>
		<p class="description"> Beyond tracking, Save-A-Spark helps you take control. Compare past months, spot patterns, and set savings goals you can actually reach. Share a household view so everyone can pitch in, and use our smart suggestions to cut waste without cutting comfort. Lower bills, less stress, and a smaller footprint—one spark at a time.</p>

</body>

</html>
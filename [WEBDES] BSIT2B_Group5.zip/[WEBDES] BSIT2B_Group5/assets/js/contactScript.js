document.addEventListener("DOMContentLoaded", function () { /* waits for the whole php to load */
  document.getElementById("emailForm").addEventListener("submit", function (e) { /* adds event listener to all input fields*/ 
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();

    const successPopup = document.getElementById("popup");
    const errorPopup = document.getElementById("errorPopup");

    if (!name || !email || !message) { /*condition for error popup*/ 
      errorPopup.classList.add("show");

      setTimeout(() => {
        errorPopup.classList.remove("show");
      }, 3000);
      return;
    }

    /*condition for successful pop-up (mailto function not utilized as of the moment)*/ 
    const subject = encodeURIComponent("Contact from " + name);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);

    window.location.href = `mailto:arabellaloraine02@gmail.com?subject=${subject}&body=${body}`;

    successPopup.classList.add("show");

    setTimeout(() => {
      successPopup.classList.remove("show");
    }, 3000);
  });
});

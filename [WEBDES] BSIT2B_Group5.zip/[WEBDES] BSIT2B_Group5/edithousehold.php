<?php
$dataFile = 'data/household.json';
$globalError = null;

// Load data
if (file_exists($dataFile)) {
    $household = json_decode(file_get_contents($dataFile), true);
    if (!is_array($household)) {
        $household = ['name' => 'My Household', 'members' => []];
    } else {
        if (!isset($household['name'])) $household['name'] = 'My Household';
        if (!isset($household['members']) || !is_array($household['members'])) {
            $household['members'] = [];
        }
    }
} else {
    $household = ['name' => 'My Household', 'members' => []];
}
$members = $household['members'];

// image upload and resizing, check for supported files
function processImageUpload($file, &$error)
{
    $allowedfileExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $fileTmpPath = $file['tmp_name'];
    $fileName = $file['name'];
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (!in_array($fileExtension, $allowedfileExtensions)) {
        $error = "Unsupported file type. Allowed: jpg, jpeg, png, gif.";
        return null;
    }

    $newFileName = uniqid('img_') . '.' . $fileExtension;
    $uploadFileDir = 'uploads/';
    $destPath = $uploadFileDir . $newFileName;

    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        $error = "Error moving the uploaded file.";
        return null;
    }

    // check for resizing <-- need to uncomment the gd extension in the php.ini file for this to work
    if (!function_exists('getimagesize')) {

         // No resizing needed, return to path
         return $destPath;
    }
    
    list($width, $height) = getimagesize($destPath);
    $maxWidth = 500;
    $maxHeight = 500;
    $scale = min($maxWidth / $width, $maxHeight / $height, 1);

    if ($scale < 1) {
        $newWidth = (int)($width * $scale);
        $newHeight = (int)($height * $scale);

        switch ($fileExtension) {
            case 'jpg':
            case 'jpeg':
                $srcImg = imagecreatefromjpeg($destPath);
                break;
            case 'png':
                $srcImg = imagecreatefrompng($destPath);
                break;
            case 'gif':
                $srcImg = imagecreatefromgif($destPath);
                break;
            default:
                $srcImg = null;
        }

        if ($srcImg) {
            $dstImg = imagecreatetruecolor($newWidth, $newHeight);
            if ($fileExtension === 'png' || $fileExtension === 'gif') {
                imagecolortransparent($dstImg, imagecolorallocatealpha($dstImg, 0, 0, 0, 127));
                imagealphablending($dstImg, false);
                imagesavealpha($dstImg, true);
            }

            imagecopyresampled($dstImg, $srcImg, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
            switch ($fileExtension) {
                case 'jpg':
                case 'jpeg':
                    imagejpeg($dstImg, $destPath);
                    break;
                case 'png':
                    imagepng($dstImg, $destPath);
                    break;
                case 'gif':
                    imagegif($dstImg, $destPath);
                    break;
            }

            imagedestroy($srcImg);
            imagedestroy($dstImg);
        }
    }

    return $destPath;
}

// handles form submissions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['edit_household_name'])) {
        $household['name'] = $_POST['household_name'];
        file_put_contents($dataFile, json_encode($household, JSON_PRETTY_PRINT));
        header("Location: edithousehold.php");
        exit();
    }

    if (isset($_POST['add_member'])) {
        $name = trim($_POST['name']);
        $role = $_POST['role'];
        $imagePath = "uploads/default.jpg";

        if (isset($_FILES['member_image']) && $_FILES['member_image']['error'] === UPLOAD_ERR_OK && !empty($_FILES['member_image']['tmp_name'])) {
            $uploadError = null;
            $newPath = processImageUpload($_FILES['member_image'], $uploadError);
            if ($newPath) {
                $imagePath = $newPath;
            } else {
                $globalError = $uploadError;
            }
        } else {
            $inputPath = trim($_POST['image_path'] ?? '');
            if (!empty($inputPath)) {
                $imagePath = $inputPath;
            }
        }

        if (!$globalError) {
            $members[] = [
                "name" => $name,
                "role" => $role,
                "image" => $imagePath
            ];
            $household['members'] = $members;
            file_put_contents($dataFile, json_encode($household, JSON_PRETTY_PRINT));
            header("Location: edithousehold.php");
            exit();
        }
    }

    if (isset($_POST['delete_member'])) {
        $index = $_POST['member_index'];
        if (isset($members[$index])) {
            $imageToDelete = $members[$index]['image'];
            if (!filter_var($imageToDelete, FILTER_VALIDATE_URL) && $imageToDelete !== "uploads/default.jpg" && file_exists($imageToDelete)) {
                unlink($imageToDelete);
            }
            array_splice($members, $index, 1);
            $household['members'] = $members;
            file_put_contents($dataFile, json_encode($household, JSON_PRETTY_PRINT));
        }
        header("Location: edithousehold.php");
        exit();
    }

    if (isset($_POST['edit_member'])) {
        $index = $_POST['member_index'];
        if (isset($members[$index])) {
            $members[$index]['name'] = $_POST['name'];
            $members[$index]['role'] = $_POST['role'];
            $household['members'] = $members;
            file_put_contents($dataFile, json_encode($household, JSON_PRETTY_PRINT));
        }
        header("Location: edithousehold.php");
        exit();
    }

    if (isset($_POST['edit_member_photo'])) {
        $index = $_POST['member_index'];
        if (isset($members[$index])) {
            $newImagePath = null;
            $uploadError = null;

            if (isset($_FILES['member_photo_file']) && $_FILES['member_photo_file']['error'] === UPLOAD_ERR_OK && !empty($_FILES['member_photo_file']['tmp_name'])) {
                $newImagePath = processImageUpload($_FILES['member_photo_file'], $uploadError);
            } else {
                $photoURL = trim($_POST['member_photo_url'] ?? '');
                if (!empty($photoURL)) {
                    $newImagePath = $photoURL;
                }
            }

            if ($uploadError) {
                $globalError = $uploadError;
            } elseif ($newImagePath) {
                $oldImage = $members[$index]['image'];
                if (!filter_var($oldImage, FILTER_VALIDATE_URL) && $oldImage !== "uploads/default.jpg" && file_exists($oldImage)) {
                    unlink($oldImage);
                }
                $members[$index]['image'] = $newImagePath;
                $household['members'] = $members;
                file_put_contents($dataFile, json_encode($household, JSON_PRETTY_PRINT));
                header("Location: edithousehold.php");
                exit();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit Household</title>
    <link rel="stylesheet" href="assets/css/edithouseholdStyle.css" />

</head>
<body>

<?php require 'views/navbar.php'; ?>

<?php if ($globalError): ?>
    <div style="background: #fdd; color: #a00; border: 1px solid #a00; padding: 15px; margin: 20px auto; width: 90%; max-width: 600px; text-align: center; border-radius: 8px; font-weight: bold;">
        UPLOAD FAILED: <?= htmlspecialchars($globalError) ?>
    </div>
<?php endif; ?>

<div class="household-container">

    <div class="left-panel">
        <div class="household-photos">
<?php

$placeholders = [
    "uploads/default.jpg", 
    "uploads/default.jpg", 
    "uploads/default.jpg"  
];

$memberImages = $placeholders;


if (isset($members[0])) {
    $memberImages[1] = $members[0]['image']; 
}
if (isset($members[1])) {
    $memberImages[0] = $members[1]['image']; 
}
if (isset($members[2])) {
    $memberImages[2] = $members[2]['image']; 
}

for ($i = 0; $i < 3; $i++):
    $imgSrc = htmlspecialchars($memberImages[$i]);
?>
            <img src="<?= $imgSrc ?>" alt="Member" class="circle <?= $i === 1 ? 'center' : 'side' ?>">
<?php endfor; ?>
        </div>

        <h2 id="household-name"><?= htmlspecialchars($household['name']) ?></h2>

        <button id="edit-name-btn" class="manage-btn">Edit</button>

        <form id="edit-name-form" method="post" style="display: none; margin-top: 10px;">
            <input type="text" name="household_name" id="household_name_input" value="<?= htmlspecialchars($household['name']) ?>" required>
            <button type="submit" name="edit_household_name" class="manage-btn" style="margin-top: 10px;">Save</button>
        </form>

    </div>

    <div class="vertical-line"></div>

    <div class="right-panel">
        <h2>EDIT HOUSEHOLD</h2>
        <h3>HOUSEHOLD MEMBERS</h3>

        <?php foreach ($members as $index => $member): ?>
            <form method="post" class="member" style="background: #f9f9f9; padding: 10px; border-radius: 8px;" enctype="multipart/form-data">
                <img src="<?= htmlspecialchars($member['image']) ?>" alt="member" class="circle-sm">

                <input type="text" name="name" value="<?= htmlspecialchars($member['name']) ?>" required style="flex: 1; padding: 5px;">

                <select name="role" required>
                    <option <?= $member['role'] === "Father" ? "selected" : "" ?>>Father</option>
                    <option <?= $member['role'] === "Mother" ? "selected" : "" ?>>Mother</option>
                    <option <?= $member['role'] === "Son" ? "selected" : "" ?>>Son</option>
                    <option <?= $member['role'] === "Daughter" ? "selected" : "" ?>>Daughter</option>
                </select>

                <input type="hidden" name="member_index" value="<?= $index ?>">

<!-- Household Members Section Buttons -->
<div class="household-members-buttons">
  <button class="manage-btn">Save</button>
  <button name="delete_member">Delete</button>
  <label class="custom-file-upload">
    Photo
    <input type="file" />
  </label>
</div>

            </form>
        <?php endforeach; ?>

        <hr>

        <div id="add-member-header" style="display: flex; align-items: center; gap: 10px;">
            <h3>Add New Member</h3>
            <button id="toggle-add-form" type="button" class="add-member-btn">+</button>
        </div>

       <form id="add-member-form" method="post" enctype="multipart/form-data" style="display: none; margin-top: 20px;">
            <input type="text" name="name" placeholder="Full Name" required style="margin-bottom: 10px; width: calc(50% - 10px); padding: 10px; display:inline-block;">
            <select name="role" required style="margin-bottom: 10px; width: calc(50% - 10px); padding: 10px; display:inline-block;">
                <option value="">--Select Role--</option>
                <option>Father</option>
                <option>Mother</option>
                <option>Son</option>
                <option>Daughter</option>
            </select>

            <div id="upload-type-toggle" class="toggle-upload-type">Switch to File Upload</div>

            <div id="upload-input-container" style="margin-bottom: 10px; width: 100%;">
                <input type="text"
                        id="add-image-url"
                        name="image_path"
                        placeholder="Profile Photo URL/Path"
                        style="width: 100%; padding: 10px; display: block;">

                <label for="add-member-image-file" class="custom-file-upload" id="custom-file-btn" style="display: none;">
                    Choose File
                </label>
                
                <input type="file"
                        name="member_image"
                        id="add-member-image-file"
                        accept="image/*"
                        style="display: none;">
                
                <span id="file-name-display" style="margin-top: 5px; font-size: 0.9em;"></span>
            </div>

            <button type="submit" name="add_member" class="manage-btn" style="margin-top: 15px;">Add Member</button>
        </form>

    </div>
</div>

<div id="photo-upload-modal" class="modal">
    <div class="modal-content">
        <span class="modal-close">&times;</span>

        <h3>Upload / Enter Photo URL</h3>

        <div id="modal-upload-type-toggle" class="toggle-upload-type">Switch to File Upload</div>

        <form id="photo-upload-form" method="post" enctype="multipart/form-data">
            <input type="hidden" name="member_index" id="modal-member-index" value="">

            <input type="text" id="modal-photo-url" name="member_photo_url" placeholder="Enter Photo URL" style="width: 100%; padding: 8px; margin-bottom: 10px; display: block;">

            <label for="modal-photo-file" class="custom-file-upload" id="modal-custom-file-btn" style="display: none; margin-bottom: 10px;">
                Choose File
            </label>
            
            <input type="file" id="modal-photo-file" name="member_photo_file" accept="image/*" style="display: none;">
            
            <span id="modal-file-name-display" style="margin-top: 5px; font-size: 0.9em;"></span>

            <button type="submit" name="edit_member_photo">Save Photo</button>
        </form>
    </div>
</div>

<script src="assets/js/edithouseholdScript.js"></script>
<?php require 'views/footer.php'; ?>

</body>
</html>
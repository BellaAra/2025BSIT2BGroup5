    // Toggle household name edit form
    const editNameBtn = document.getElementById('edit-name-btn');
    const editNameForm = document.getElementById('edit-name-form');
    const householdName = document.getElementById('household-name');
    const householdNameInput = document.getElementById('household_name_input');

    editNameBtn.addEventListener('click', () => {
        editNameForm.style.display = 'block';
        editNameBtn.style.display = 'none';
        householdName.style.display = 'none';
        householdNameInput.focus();
    });

    // ADD MEMBER
    const toggleAddFormBtn = document.getElementById('toggle-add-form');
    const addMemberForm = document.getElementById('add-member-form');

    toggleAddFormBtn.addEventListener('click', () => {
        const isHidden = addMemberForm.style.display === 'none' || addMemberForm.style.display === '';
        addMemberForm.style.display = isHidden ? 'block' : 'none';
        toggleAddFormBtn.textContent = isHidden ? '-' : '+';
    });

    // UPLOADING ADDED MEMBER
    const uploadTypeToggle = document.getElementById('upload-type-toggle');
    const addImageURLInput = document.getElementById('add-image-url');
    const addImageFileInput = document.getElementById('add-member-image-file');
    const customFileBtn = document.getElementById('custom-file-btn');
    const fileNameDisplay = document.getElementById('file-name-display');

    let usingURL = true;

    uploadTypeToggle.addEventListener('click', () => {
        usingURL = !usingURL;
        if (usingURL) {
            addImageURLInput.style.display = 'block';
            customFileBtn.style.display = 'none';
            fileNameDisplay.textContent = '';
            addImageFileInput.value = '';
            uploadTypeToggle.textContent = 'Switch to File Upload';
        } else {
            addImageURLInput.style.display = 'none';
            customFileBtn.style.display = 'block';
            uploadTypeToggle.textContent = 'Switch to URL Input';
            addImageURLInput.value = '';
        }
    });

    customFileBtn.addEventListener('click', () => {
        addImageFileInput.click();
    });

    addImageFileInput.addEventListener('change', () => {
        const file = addImageFileInput.files[0];
        fileNameDisplay.textContent = file ? file.name : '';
    });

    // EDITING PHOTO
    const modal = document.getElementById('photo-upload-modal');
    const modalClose = modal.querySelector('.modal-close');
    const modalMemberIndexInput = document.getElementById('modal-member-index');
    const modalPhotoURL = document.getElementById('modal-photo-url');
    const modalPhotoFile = document.getElementById('modal-photo-file');
    const modalCustomFileBtn = document.getElementById('modal-custom-file-btn'); 
    const modalFileNameDisplay = document.getElementById('modal-file-name-display'); 
    const modalUploadToggle = document.getElementById('modal-upload-type-toggle');

    document.querySelectorAll('.edit-photo-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            modalMemberIndexInput.value = btn.getAttribute('data-member-index');
 
            modalPhotoURL.value = '';
            modalPhotoFile.value = '';
            modalPhotoURL.style.display = 'block';
            modalCustomFileBtn.style.display = 'none'; 
            modalFileNameDisplay.textContent = '';
            modalUploadToggle.textContent = 'Switch to File Upload';
            modal.style.display = 'block';
        });
    });

    modalClose.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    modalUploadToggle.addEventListener('click', () => {
        if (modalPhotoURL.style.display !== 'none') {

            modalPhotoURL.style.display = 'none';
            modalCustomFileBtn.style.display = 'block'; 
            modalPhotoFile.style.display = 'none'; 
            modalFileNameDisplay.textContent = ''; 
            modalPhotoFile.value = ''; 
            modalUploadToggle.textContent = 'Switch to URL Input';
        } else {

            modalPhotoURL.style.display = 'block';
            modalCustomFileBtn.style.display = 'none'; 
            modalPhotoFile.style.display = 'none'; 
            modalFileNameDisplay.textContent = ''; 
            modalPhotoURL.value = ''; 
            modalUploadToggle.textContent = 'Switch to File Upload';
        }
    });
    
    modalCustomFileBtn.addEventListener('click', () => {
        modalPhotoFile.click(); 
    });

    // Display file name of photo
    modalPhotoFile.addEventListener('change', () => {
        const file = modalPhotoFile.files[0];
        modalFileNameDisplay.textContent = file ? file.name : '';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });